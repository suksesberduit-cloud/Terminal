const CACHE_NAME = 'trmnl-v1';
const CORE_ASSETS = ['./index.html', './manifest.json'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // network-first untuk data live (API), cache-first untuk shell app
  const url = event.request.url;
  const isApi = url.includes('coingecko.com') || url.includes('rss2json.com');
  if (isApi) return; // biarkan langsung ke network, jangan cache data live

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
