# TRMNL — Cara Build APK

Paket ini berisi web app (folder `app/`) + workflow GitHub Actions (`.github/workflows/build-apk.yml`)
yang men-scaffold project Capacitor dari nol dan build APK debug, mengikuti pola yang sama
dengan project Reminder/Kakeibo sebelumnya.

## Langkah build via browser HP (tanpa git CLI, cukup 2 file di-upload)

1. Buat repo GitHub baru (public atau private), misal nama: `trmnl`.
2. Buat file workflow lewat GitHub web UI: di repo, klik **Add file → Create new file**,
   isi nama path persis: `.github/workflows/build-apk.yml`, lalu copy-paste isi file
   `build-apk.yml` dari paket ini ke dalamnya → **Commit**.
3. Upload file **`trmnl-app.zip` ini apa adanya** (tidak perlu di-extract dulu) ke root repo —
   drag & drop lewat GitHub web UI, biarkan namanya tetap `trmnl-app.zip`.
   Workflow-nya sudah otomatis meng-extract zip ini sendiri saat build jalan.
4. Buka tab **Actions** di repo → pilih workflow **"Build TRMNL APK"** → klik **Run workflow**.
5. Tunggu ± 3-5 menit sampai selesai (centang hijau).
6. Buka run yang selesai tadi → scroll ke bagian **Artifacts** → download **TRMNL-debug-apk**.
7. Extract zip artifact tersebut, di dalamnya ada `app-debug.apk` — itu yang diinstall ke HP Android.

**Alternatif:** kalau lebih nyaman, kamu tetap bisa extract zip ini dan upload folder `app/`
apa adanya (bukan sebagai zip) — workflow otomatis mendeteksi dan pakai folder itu langsung
kalau tidak ada file `trmnl-app.zip` di root.

## Fitur AI (jawaban real-time ala Claude) — opsional tapi direkomendasikan

Command bar di app ini bisa menjawab pertanyaan bebas apa saja pakai Gemini API
(Google Search grounding) — tapi butuh setup terpisah dulu supaya API key aman.
Ikuti panduan lengkap di `worker/SETUP.md` (semua lewat browser HP, tidak perlu CLI).

Kalau langkah ini dilewati dulu, app tetap jalan normal — command bar otomatis
fallback ke pencarian berita Google News biasa (tanpa jawaban narasi AI).

## Catatan penting

- Ini APK **debug** (belum signed dengan keystore permanen) — cukup untuk pemakaian pribadi,
  tapi Android akan tetap kasih warning "unknown source" saat install (normal, karena bukan dari Play Store).
- Kalau nanti mau publish ke Play Store atau butuh APK yang stabil untuk update berkelanjutan
  (tidak perlu uninstall-reinstall tiap update), langkah berikutnya adalah generate keystore permanen
  dan ubah workflow ke `assembleRelease` — sama seperti yang sudah dilakukan untuk Kakeibo.
- Package ID app ini: `id.trmnl.app`. Ganti di `build-apk.yml` (bagian `cap init`) kalau mau ID lain.
- App butuh koneksi internet untuk fitur live (harga crypto & berita) — permission internet
  sudah otomatis ditambahkan Capacitor secara default.
