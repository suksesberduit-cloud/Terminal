# Setup AI Worker (jawaban ala Claude dengan akses internet) — via browser HP

Tidak perlu install apapun, tidak perlu CLI/komputer. Semua lewat browser.

## Langkah 1 — Ambil API key Gemini (gratis)

1. Buka https://aistudio.google.com/apikey di browser HP
2. Login pakai akun Google, klik **"Create API key"**
3. Salin key-nya (formatnya `AIza...`) — simpan sementara, jangan share ke siapa pun

## Langkah 2 — Buat Cloudflare Worker (gratis)

1. Buka https://dash.cloudflare.com → daftar akun gratis kalau belum punya
2. Di sidebar, pilih **Workers & Pages** → **Create** → **Create Worker**
3. Kasih nama, misal `trmnl-ai` → **Deploy** (nanti dapat URL default seperti `trmnl-ai.<username>.workers.dev`)
4. Klik **Edit code** — hapus semua kode default, ganti dengan isi file `gemini-worker.js` dari paket ini (copy-paste manual dari file, atau upload kalau ada opsi upload)
5. Klik **Save and deploy**

## Langkah 3 — Set secrets (JANGAN taruh di kode langsung)

Masih di halaman Worker kamu:
1. Buka tab **Settings** → **Variables and Secrets**
2. Tambah secret baru:
   - Name: `GEMINI_API_KEY` → Value: API key dari Langkah 1 → tipe **Secret** (bukan plaintext)
   - Name: `APP_SECRET` → Value: bikin string acak sendiri (misal `trmnl-x9f2-rahasia`) → tipe **Secret**
3. (Opsional) tambah variable biasa `GEMINI_MODEL` kalau mau ganti model default (`gemini-2.5-flash`)
4. **Save and deploy** lagi supaya secret aktif

## Langkah 4 — Sambungkan ke aplikasi TRMNL

1. Catat URL worker kamu, misal: `https://trmnl-ai.namakamu.workers.dev`
2. Buka file `app/index.html`, cari bagian:
   ```js
   const AI_WORKER_URL = 'GANTI-DENGAN-URL-WORKER-KAMU';
   const AI_APP_SECRET = 'GANTI-DENGAN-APP-SECRET-YANG-SAMA';
   ```
3. Ganti `AI_WORKER_URL` dengan URL worker kamu + `/` (contoh: `https://trmnl-ai.namakamu.workers.dev/`)
4. Ganti `AI_APP_SECRET` dengan **string yang SAMA PERSIS** dengan `APP_SECRET` yang kamu set di Langkah 3
5. Simpan, lalu upload ulang ke repo GitHub / rebuild APK seperti biasa

## Catatan penting soal keamanan & batas

- Skema `APP_SECRET` ini **bukan keamanan sempurna** — karena file `index.html` publik, orang yang cukup niat bisa buka "view source" dan menemukan secret itu juga. Ini hanya menaikkan sedikit hambatan, bukan mengunci penuh.
- Untuk perlindungan lebih kuat: di dashboard Cloudflare, tambahkan **Rate Limiting Rule** pada route worker ini (misal maksimal 20 request/menit per IP) — fitur ini ada di tier gratis Cloudflare.
- Tier gratis Gemini (~1.000-1.500 request/hari tergantung model) berlaku untuk API key kamu secara keseluruhan — kalau worker ini bocor dan disalahgunakan orang lain, jatahmu ikut terpakai. Pantau pemakaian di https://aistudio.google.com secara berkala.
- Prompt yang kamu kirim di tier gratis Gemini boleh dipakai Google untuk melatih model mereka — hindari menanyakan data pribadi/posisi investasi sensitif lewat fitur ini kalau itu jadi concern.

## Bonus: endpoint /econ-calendar (tidak butuh setup tambahan)

Worker ini juga otomatis menyediakan endpoint `/econ-calendar` yang meng-cache data
kalender ekonomi Forex Factory selama 15 menit di edge Cloudflare. Ini penting karena
Forex Factory membatasi hanya 2 request/5 menit dari satu sumber — dengan worker ini,
SEMUA user app kamu berbagi 1 cache yang sama, jadi tidak akan pernah lagi membebani
(atau kena limit dari) Forex Factory secara langsung. Endpoint ini otomatis aktif
begitu kamu deploy worker-nya — index.html sudah otomatis memakainya duluan sebelum
fallback ke cara lama, tidak perlu setting tambahan apa pun di luar yang sudah
dijelaskan di atas.
