# Setup AI Worker (jawaban ala Claude dengan akses internet) — via browser HP

Tidak perlu install apapun, tidak perlu CLI/komputer. Semua lewat browser.

## Langkah 1 — Ambil API key Gemini (gratis)

1. Buka https://aistudio.google.com/apikey di browser HP
2. Login pakai akun Google, klik **"Create API key"**
3. Salin key-nya (formatnya `AIza...`) — simpan sementara, jangan share ke siapa pun

## Langkah 2 — Buat Cloudflare Worker (gratis)

1. Buka https://dash.cloudflare.com → daftar akun gratis kalau belum punya
2. Di sidebar, pilih **Workers & Pages** → **Create** → **Create Worker**
3. Kasih nama, misal `trmnl-ai` → **Deploy** (nanti dapat URL default seperti `trmnl-ai.<username>.workers.dev`)
4. Klik **Edit code** — hapus semua kode default, ganti dengan isi file `gemini-worker.js` dari paket ini (copy-paste manual dari file, atau upload kalau ada opsi upload)
5. Klik **Save and deploy**

## Langkah 3 — Set secrets (JANGAN taruh di kode langsung)

Masih di halaman Worker kamu:
1. Buka tab **Settings** → **Variables and Secrets**
2. Tambah secret baru:
   - Name: `GEMINI_API_KEY` → Value: API key dari Langkah 1 → tipe **Secret** (bukan plaintext)
   - Name: `APP_SECRET` → Value: bikin string acak sendiri (misal `trmnl-x9f2-rahasia`) → tipe **Secret**
3. (Opsional) tambah variable biasa `GEMINI_MODEL` kalau mau ganti model default (`gemini-2.5-flash` — ⚠️ model ini dijadwalkan Google mati 16 Oktober 2026, kemungkinan perlu diganti lagi sekitar tanggal itu)
4. (Opsional, disarankan) tambah secret `FMP_API_KEY` — daftar gratis di https://site.financialmodelingprep.com (tanpa kartu kredit) untuk sumber kalender ekonomi yang lebih tahan banting daripada Forex Factory. Kalau dilewati, worker otomatis pakai cara lama.
5. **Save and deploy** lagi supaya secret aktif

## Langkah 4 — Sambungkan ke aplikasi TRMNL

1. Catat URL worker kamu, misal: `https://trmnl-ai.namakamu.workers.dev`
2. Buka file `app/index.html`, cari bagian:
   ```js
   const AI_WORKER_URL = 'GANTI-DENGAN-URL-WORKER-KAMU';
   const AI_APP_SECRET = 'GANTI-DENGAN-APP-SECRET-YANG-SAMA';
   ```
3. Ganti `AI_WORKER_URL` dengan URL worker kamu + `/` (contoh: `https://trmnl-ai.namakamu.workers.dev/`)
4. Ganti `AI_APP_SECRET` dengan **string yang SAMA PERSIS** dengan `APP_SECRET` yang kamu set di Langkah 3
5. Simpan, lalu upload ulang ke repo GitHub / rebuild APK seperti biasa

## Catatan penting soal keamanan & batas

- Skema `APP_SECRET` ini **bukan keamanan sempurna** — karena file `index.html` publik, orang yang cukup niat bisa buka "view source" dan menemukan secret itu juga. Ini hanya menaikkan sedikit hambatan, bukan mengunci penuh.
- Untuk perlindungan lebih kuat: di dashboard Cloudflare, tambahkan **Rate Limiting Rule** pada route worker ini (misal maksimal 20 request/menit per IP) — fitur ini ada di tier gratis Cloudflare.
- Tier gratis Gemini (~1.000-1.500 request/hari tergantung model) berlaku untuk API key kamu secara keseluruhan — kalau worker ini bocor dan disalahgunakan orang lain, jatahmu ikut terpakai. Pantau pemakaian di https://aistudio.google.com secara berkala.
- Prompt yang kamu kirim di tier gratis Gemini boleh dipakai Google untuk melatih model mereka — hindari menanyakan data pribadi/posisi investasi sensitif lewat fitur ini kalau itu jadi concern.

## Bonus: endpoint /econ-calendar (tidak butuh setup tambahan)

Worker ini juga otomatis menyediakan endpoint `/econ-calendar`. Kalau secret
`FMP_API_KEY` diisi (lihat Langkah 3), ini jadi sumber utama (lebih andal).
Kalau tidak, otomatis fallback fetch langsung Forex Factory + cache 15 menit
di edge Cloudflare (mengurangi tapi tidak menghilangkan risiko kena rate-limit
FF). Endpoint ini otomatis aktif begitu kamu deploy worker — index.html sudah
otomatis memakainya duluan sebelum fallback ke cara lama.

## Bonus: endpoint /congress-trades (⚠️ eksperimental, perlu 1x verifikasi manual)

Endpoint ini scrape data dari capitoltrades.com (lihat komentar panjang di
kode worker untuk detail teknisnya). Karena ditulis berdasarkan riset (bukan
hasil tes langsung), kemungkinan besar perlu 1 putaran penyesuaian. Cara cek:

1. Buka `https://<url-worker-kamu>/congress-trades?debug=1` langsung di browser HP
2. Kalau muncul `"found": 0` dan ada `"raw_sample"` — salin isi `raw_sample`
   itu (potongan data mentah dari capitoltrades.com) dan kirim ke Claude di
   sesi berikutnya, supaya nama field di parser bisa disesuaikan
3. Kalau muncul `"found"` dengan angka >0 dan data di `"trades"` terlihat
   masuk akal (nama politisi, ticker saham, dst) — berarti sudah jalan,
   tidak perlu langkah tambahan
