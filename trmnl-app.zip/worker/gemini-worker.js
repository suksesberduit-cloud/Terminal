/**
 * TRMNL AI Worker — proxy aman ke Gemini API (Grounding with Google Search)
 *
 * Kenapa perlu ini: API key Gemini TIDAK BOLEH ditaruh di kode client-side
 * (index.html) yang di-hosting publik/APK, karena siapa saja bisa ambil key
 * itu dan pakai jatah kuota gratis kamu. Worker ini jalan di server Cloudflare,
 * key disimpan sebagai secret di sana — tidak pernah terkirim ke browser user.
 *
 * SETUP (lihat SETUP.md untuk panduan lengkap lewat browser HP):
 * 1. Deploy file ini sebagai Cloudflare Worker
 * 2. Set secret: GEMINI_API_KEY (dari Google AI Studio)
 * 3. Set secret: APP_SECRET (bebas, string acak buatanmu sendiri)
 * 4. (Opsional) Set variable: GEMINI_MODEL (default: gemini-2.5-flash)
 * 5. Salin URL worker (https://xxx.workers.dev) ke index.html
 */

export default {
  async fetch(request, env) {
    const corsHeaders = {
      // Untuk keamanan lebih baik, ganti '*' dengan domain GitHub Pages kamu
      // setelah deploy, misal: 'https://username.github.io'
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-App-Secret',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }
    if (request.method !== 'POST') {
      return new Response('Method not allowed', { status: 405, headers: corsHeaders });
    }

    // Proteksi dasar — bukan keamanan sempurna (secret tetap ada di client),
    // tapi cukup mencegah bot/scraper acak menemukan & memakai endpoint ini.
    // Proteksi nyata: batasi juga lewat Cloudflare dashboard (rate limiting rule).
    const appSecret = request.headers.get('X-App-Secret');
    if (!env.APP_SECRET || appSecret !== env.APP_SECRET) {
      return new Response(JSON.stringify({ error: 'unauthorized' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify({ error: 'bad_json' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const query = (body.query || '').toString().slice(0, 500);
    if (!query.trim()) {
      return new Response(JSON.stringify({ error: 'empty_query' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
    const prompt = `Jawab pertanyaan berikut dalam Bahasa Indonesia, singkat (maksimal 4-5 kalimat), jelas, dan berbasis informasi paling terkini yang kamu temukan. Jangan mengarang jika tidak yakin.\n\nPertanyaan: ${query}`;

    let geminiRes;
    try {
      geminiRes = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': env.GEMINI_API_KEY,
          },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            tools: [{ google_search: {} }],
          }),
        }
      );
    } catch (e) {
      return new Response(JSON.stringify({ error: 'network_error', detail: String(e) }), {
        status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      return new Response(JSON.stringify({ error: 'gemini_error', detail: errText.slice(0, 400) }), {
        status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const data = await geminiRes.json();
    const candidate = data.candidates && data.candidates[0];
    const text =
      (candidate && candidate.content && candidate.content.parts
        ? candidate.content.parts.map((p) => p.text || '').join('')
        : '') || '(Tidak ada jawaban dari model)';

    // Field grounding metadata bisa berbeda nama antar versi API — coba beberapa kemungkinan.
    const gm = candidate && candidate.groundingMetadata;
    const chunks = (gm && (gm.groundingChunks || gm.groundingAttributions)) || [];
    const sources = chunks
      .map((c) => {
        const web = c.web || c.source || {};
        return web.uri || web.url ? { title: web.title || web.uri || web.url, url: web.uri || web.url } : null;
      })
      .filter(Boolean);

    return new Response(JSON.stringify({ text, sources }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  },
};
