/**
 * TRMNL Worker — proxy aman ke Gemini API (AI) + cache kalender ekonomi
 *
 * Kenapa perlu ini: 
 * 1) API key Gemini TIDAK BOLEH ditaruh di kode client-side (index.html) yang
 *    di-hosting publik/APK, karena siapa saja bisa ambil key itu dan pakai
 *    jatah kuota gratis kamu. Worker ini jalan di server Cloudflare, key
 *    disimpan sebagai secret di sana — tidak pernah terkirim ke browser user.
 * 2) Kalender ekonomi (Forex Factory) membatasi 2 request/5 menit dari SATU
 *    sumber. Kalau tiap HP yang buka app ini fetch langsung, gampang kena
 *    limit itu. Worker ini fetch SEKALI per 15 menit lalu simpan di cache
 *    edge Cloudflare — semua user ambil dari cache itu, jadi tidak pernah
 *    lagi membebani (atau kena limit dari) Forex Factory secara langsung.
 *
 * SETUP (lihat SETUP.md untuk panduan lengkap lewat browser HP):
 * 1. Deploy file ini sebagai Cloudflare Worker
 * 2. Set secret: GEMINI_API_KEY (dari Google AI Studio)
 * 3. Set secret: APP_SECRET (bebas, string acak buatanmu sendiri)
 * 4. (Opsional) Set variable: GEMINI_MODEL (default: gemini-2.0-flash)
 * 5. Salin URL worker (https://xxx.workers.dev) ke index.html
 *    (dipakai otomatis untuk fitur AI *dan* kalender ekonomi sekaligus)
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === '/econ-calendar') {
      return handleEconCalendar(request, ctx);
    }
    if (url.pathname === '/congress-trades') {
      return handleCongressTrades(request, ctx);
    }
    return handleAsk(request, env);
  },
};

/* ============================================================
   /congress-trades — cache edge 30 menit, tidak perlu APP_SECRET.
   congressinvests.com di-hosting di Railway tier gratis yang
   "tidur" kalau idle >10 menit, jadi request pertama sering
   gagal/lambat (cold-start). Worker punya jatah waktu tunggu
   lebih longgar daripada browser HP, jadi retry di sini lebih
   andal — dan hasilnya di-cache, jadi user berikutnya instan.
   ============================================================ */
async function handleCongressTrades(request, ctx) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };
  if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const cacheKey = new Request('https://trmnl-congress-cache/recent', { method: 'GET' });
  const cache = caches.default;

  let cached = await cache.match(cacheKey);
  if (cached) return new Response(cached.body, { headers: { ...corsHeaders, 'Content-Type': 'application/json', 'X-Cache': 'HIT' } });

  const upstreamUrl = 'https://congressinfor-production.up.railway.app/trades/recent?limit=30&days=45';

  async function attempt() {
    const r = await fetch(upstreamUrl, { cf: { cacheTtl: 0 } });
    if (!r.ok) throw new Error('upstream not ok: ' + r.status);
    const d = await r.json();
    if (!Array.isArray(d.trades)) throw new Error('format tidak sesuai');
    return d;
  }

  let data;
  try {
    data = await attempt();
  } catch (e1) {
    // beri jeda untuk Railway selesai "bangun" dari cold-start, lalu coba lagi
    await new Promise((res) => setTimeout(res, 5000));
    try {
      data = await attempt();
    } catch (e2) {
      return new Response(JSON.stringify({ error: 'upstream_failed', detail: String(e2) }), {
        status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  }

  const resp = new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=1800', 'X-Cache': 'MISS' },
  });
  ctx.waitUntil(cache.put(cacheKey, resp.clone()));
  return resp;
}

/* ============================================================
   /econ-calendar — cache edge 15 menit, tidak perlu APP_SECRET
   (data publik, tidak sensitif, jadi tidak perlu proteksi seketat /ask)
   ============================================================ */
async function handleEconCalendar(request, ctx) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };
  if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const cacheKey = new Request('https://trmnl-econ-cache/ff-calendar', { method: 'GET' });
  const cache = caches.default;

  let cached = await cache.match(cacheKey);
  if (cached) return new Response(cached.body, { headers: { ...corsHeaders, 'Content-Type': 'application/json', 'X-Cache': 'HIT' } });

  let text;
  try {
    const r = await fetch('https://nfs.faireconomy.media/ff_calendar_thisweek.json', {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TRMNL-Worker/1.0)' },
    });
    text = await r.text();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'fetch_failed', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (text.trim().startsWith('<')) {
    // Forex Factory sedang rate-limit bahkan untuk worker kita — jangan cache respons kosong ini.
    return new Response(JSON.stringify({ error: 'upstream_rate_limited' }), {
      status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const resp = new Response(text, {
    headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=900', 'X-Cache': 'MISS' },
  });
  ctx.waitUntil(cache.put(cacheKey, resp.clone()));
  return resp;
}

/* ============================================================
   /ask — proxy ke Gemini API (fitur AI, butuh APP_SECRET)
   ============================================================ */
async function handleAsk(request, env) {
  const corsHeaders = {
    // Untuk keamanan lebih baik, ganti '*' dengan domain GitHub Pages kamu
    // setelah deploy, misal: 'https://username.github.io'
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-App-Secret',
  };

  if (request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders });
  }

  // Proteksi dasar — bukan keamanan sempurna (secret tetap ada di client),
  // tapi cukup mencegah bot/scraper acak menemukan & memakai endpoint ini.
  // Proteksi nyata: batasi juga lewat Cloudflare dashboard (rate limiting rule).
  const appSecret = request.headers.get('X-App-Secret');
  if (!env.APP_SECRET || appSecret !== env.APP_SECRET) {
    return new Response(JSON.stringify({ error: 'unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response(JSON.stringify({ error: 'bad_json' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const query = (body.query || '').toString().slice(0, 500);
  if (!query.trim()) {
    return new Response(JSON.stringify({ error: 'empty_query' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const model = env.GEMINI_MODEL || 'gemini-2.0-flash';
  const prompt = `Jawab pertanyaan berikut dalam Bahasa Indonesia, singkat (maksimal 4-5 kalimat), jelas, dan berbasis informasi paling terkini yang kamu temukan. Jangan mengarang jika tidak yakin.\n\nPertanyaan: ${query}`;

  let geminiRes;
  try {
    geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': env.GEMINI_API_KEY,
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          tools: [{ google_search: {} }],
        }),
      }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: 'network_error', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (!geminiRes.ok) {
    const errText = await geminiRes.text();
    return new Response(JSON.stringify({ error: 'gemini_error', detail: errText.slice(0, 400) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const data = await geminiRes.json();
  const candidate = data.candidates && data.candidates[0];
  const text =
    (candidate && candidate.content && candidate.content.parts
      ? candidate.content.parts.map((p) => p.text || '').join('')
      : '') || '(Tidak ada jawaban dari model)';

  // Field grounding metadata bisa berbeda nama antar versi API — coba beberapa kemungkinan.
  const gm = candidate && candidate.groundingMetadata;
  const chunks = (gm && (gm.groundingChunks || gm.groundingAttributions)) || [];
  const sources = chunks
    .map((c) => {
      const web = c.web || c.source || {};
      return web.uri || web.url ? { title: web.title || web.uri || web.url, url: web.uri || web.url } : null;
    })
    .filter(Boolean);

  return new Response(JSON.stringify({ text, sources }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

