/**
 * TRMNL Worker — proxy aman ke Gemini API (AI) + cache kalender ekonomi
 *
 * Kenapa perlu ini: 
 * 1) API key Gemini TIDAK BOLEH ditaruh di kode client-side (index.html) yang
 *    di-hosting publik/APK, karena siapa saja bisa ambil key itu dan pakai
 *    jatah kuota gratis kamu. Worker ini jalan di server Cloudflare, key
 *    disimpan sebagai secret di sana — tidak pernah terkirim ke browser user.
 * 2) Kalender ekonomi (Forex Factory) membatasi 2 request/5 menit dari SATU
 *    sumber. Kalau tiap HP yang buka app ini fetch langsung, gampang kena
 *    limit itu. Worker ini fetch SEKALI per 15 menit lalu simpan di cache
 *    edge Cloudflare — semua user ambil dari cache itu, jadi tidak pernah
 *    lagi membebani (atau kena limit dari) Forex Factory secara langsung.
 *
 * SETUP (lihat SETUP.md untuk panduan lengkap lewat browser HP):
 * 1. Deploy file ini sebagai Cloudflare Worker
 * 2. Set secret: GEMINI_API_KEY (dari Google AI Studio)
 * 3. Set secret: APP_SECRET (bebas, string acak buatanmu sendiri)
 * 4. (Opsional) Set variable: GEMINI_MODEL (default: gemini-2.5-flash — LIHAT
 *    CATATAN PENTING di bawah sebelum mengubah ini)
 * 5. (Opsional, disarankan) Set secret: FMP_API_KEY — key gratis dari
 *    financialmodelingprep.com, dipakai sebagai sumber UTAMA kalender
 *    ekonomi yang jauh lebih tahan banting daripada Forex Factory (lihat
 *    catatan di handleEconCalendar). Kalau tidak diisi, worker otomatis
 *    pakai jalur lama (Forex Factory langsung).
 * 6. Salin URL worker (https://xxx.workers.dev) ke index.html
 *    (dipakai otomatis untuk fitur AI, kalender ekonomi, dan congress trades)
 *
 * CATATAN PENTING SOAL MODEL GEMINI (per 11 Sep 2026):
 * - gemini-2.0-flash SUDAH SEPENUHNYA DIMATIKAN Google per 1 Juni 2026
 *   (bukan rate-limit, endpoint-nya benar-benar hilang — makanya error 404
 *   "no longer available"). Tidak bisa diperbaiki dari sisi kita, harus ganti model.
 * - gemini-2.5-flash (dipakai di bawah) MASIH AKTIF dan gratis grounding
 *   (Google Search) tanpa perlu billing account — tapi Google sudah
 *   mengumumkan jadwal matinya: 16 Oktober 2026. Artinya perbaikan ini
 *   PERLU DIULANG sekitar pertengahan Oktober 2026 — jangan kaget kalau
 *   nanti muncul error gemini_error/404 lagi sekitar tanggal itu.
 * - gemini-3.x (3-flash-preview, 3.5/3.6/3.7/3.8-flash) TIDAK cocok untuk
 *   kita sekarang: grounding (Google Search) di tier gratis-nya "Not
 *   available" — harus aktifkan billing account (kartu kredit) di Google
 *   Cloud dulu baru grounding jalan (meski kuotanya sendiri tetap gratis
 *   5.000/bulan). Ini kemungkinan besar penyebab error 429 quota exceeded
 *   yang kamu alami waktu pakai gemini-3.6-flash kemarin.
 *   Kalau nanti Oktober 2026 gemini-2.5-flash benar-benar mati, opsinya:
 *   (a) aktifkan billing lalu pindah ke gemini-3-flash-preview, atau
 *   (b) cek lagi model Gemini gratis+grounding yang berlaku saat itu.
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === '/econ-calendar') {
      return handleEconCalendar(request, env, ctx);
    }
    if (url.pathname === '/congress-trades') {
      return handleCongressTrades(request, ctx);
    }
    return handleAsk(request, env);
  },
};

/* ============================================================
   /congress-trades — cache edge 3 jam, tidak perlu APP_SECRET.

   RISET 11 Sep 2026 (jujur soal batasannya): TIDAK ADA lagi JSON API
   gratis+resmi yang aktif untuk data ini. Dua sumber lama sudah
   dikonfirmasi mati:
   - Senate/House Stock Watcher (S3) — proyek open-source-nya sudah
     tidak aktif/data tidak update.
   - congressinvests.com (Railway) — sudah tidak merespons sama sekali,
     bukan cuma cold-start lagi seperti dugaan sesi sebelumnya.
   Opsi berbayar termurah yang ditemukan (Quiver Quantitative Hobbyist)
   $30/bulan — di luar prinsip "gratis" proyek ini.

   SOLUSI YANG DIPAKAI: capitoltrades.com (situs gratis paling lengkap
   & terus di-update untuk data ini) TIDAK punya REST API publik, tapi
   situsnya dibangun pakai Next.js yang me-render datanya di server lalu
   menyisipkan sebagai JSON mentah di dalam <script>self.__next_f.push(...)</script>
   pada HTML awal (bagian dari mekanisme "React Server Component" Next.js).
   Ini teknik yang sama dipakai proyek open-source lain (mis. capitol-trades-mcp)
   untuk baca data ini tanpa browser/JS engine — worker cukup fetch HTML
   biasa lalu cari JSON itu di dalamnya. Lebih tahan lama daripada scrape
   tabel HTML biasa karena tidak bergantung pada nama class CSS yang bisa
   berubah kapan saja saat mereka redesign tampilan.

   ⚠️ CATATAN JUJUR PENTING: saya menulis parser ini berdasarkan riset
   (bukan hasil coba-coba langsung ke capitoltrades.com dari sini, karena
   lingkungan saya tidak bisa mengakses jaringan luar untuk verifikasi
   langsung). Nama field JSON di bawah (politician/asset/txType/dst) adalah
   perkiraan terbaik dari dokumentasi proyek open-source yang membaca
   sumber sama. KEMUNGKINAN BESAR field-nya tidak 100% cocok di percobaan
   pertama. Kalau /congress-trades masih mengembalikan {"error":"parse_empty"},
   itu TANDA parsernya perlu disesuaikan — bukan berarti pendekatannya
   salah. Cara memperbaikinya: buka
   https://<worker-url>/congress-trades?debug=1 dari browser, salin isi
   "raw_sample" yang muncul, lalu kirim ke saya di sesi berikutnya supaya
   saya sesuaikan nama field-nya dengan struktur JSON yang sebenarnya.
   ============================================================ */
async function handleCongressTrades(request, ctx) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };
  if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const url = new URL(request.url);
  const debug = url.searchParams.get('debug') === '1';

  const cacheKey = new Request('https://trmnl-congress-cache/capitoltrades-v1', { method: 'GET' });
  const cache = caches.default;

  if (!debug) {
    let cached = await cache.match(cacheKey);
    if (cached) return new Response(cached.body, { headers: { ...corsHeaders, 'Content-Type': 'application/json', 'X-Cache': 'HIT' } });
  }

  const upstreamUrl = 'https://www.capitoltrades.com/trades?pageSize=100&txDate=90d';
  let html;
  try {
    const r = await fetch(upstreamUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Mobile Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
      },
    });
    if (!r.ok) throw new Error('upstream status ' + r.status);
    html = await r.text();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'fetch_failed', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  let trades;
  let sample = '';
  try {
    const parsed = parseCapitolTradesFlightJson(html);
    trades = parsed.trades;
    sample = parsed.sample;
  } catch (e) {
    return new Response(JSON.stringify({ error: 'parse_error', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (debug) {
    return new Response(JSON.stringify({ found: trades.length, trades: trades.slice(0, 5), raw_sample: sample }, null, 2), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (!trades.length) {
    // JANGAN cache hasil kosong — supaya percobaan berikutnya (setelah parser
    // diperbaiki) langsung dapat data baru, bukan tertahan cache lama.
    return new Response(JSON.stringify({
      error: 'parse_empty',
      hint: 'Tambahkan ?debug=1 di URL worker ini untuk lihat contoh data mentah, lalu kirim ke Claude untuk diperbaiki.',
    }), { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  const data = { trades };
  const resp = new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=10800', 'X-Cache': 'MISS' },
  });
  ctx.waitUntil(cache.put(cacheKey, resp.clone()));
  return resp;
}

/**
 * Cari semua <script>self.__next_f.push([1,"..."])</script> di HTML,
 * gabungkan isinya (setelah unescape string JS), lalu cari objek JSON
 * yang "berbentuk" seperti data trade (dikenali dari beberapa nama field
 * kandidat) dengan menghitung kurung kurawal secara manual (bukan regex
 * bersarang, karena regex tidak bisa menghitung nested braces dengan andal).
 */
function parseCapitolTradesFlightJson(html) {
  const chunkRe = /self\.__next_f\.push\(\[\s*1\s*,\s*"((?:[^"\\]|\\.)*)"\s*\]\)/g;
  let combined = '';
  let m;
  while ((m = chunkRe.exec(html))) {
    try {
      // payload adalah string JS ter-escape (\n, \", \\u... dst) — unescape
      // dengan trik JSON.parse pada string yang dibungkus tanda kutip.
      combined += JSON.parse('"' + m[1] + '"');
    } catch (e) { /* lewati chunk yang gagal di-unescape, lanjut ke chunk lain */ }
  }

  if (!combined) {
    throw new Error('tidak ditemukan chunk self.__next_f.push sama sekali — kemungkinan struktur halaman sudah berubah total (bukan Next.js App Router lagi, atau butuh JS untuk render)');
  }

  // Kandidat nama field unik yang kemungkinan menandai satu record trade.
  // "reportingGap" dipakai sebagai anchor utama karena nama field ini
  // cukup spesifik/jarang muncul di konteks lain pada halaman yang sama.
  const anchors = ['"reportingGap"', '"politician":{', '"txType"'];
  const foundStarts = new Set();
  for (const anchor of anchors) {
    let idx = combined.indexOf(anchor);
    while (idx !== -1) {
      const objStr = extractEnclosingObject(combined, idx);
      if (objStr) foundStarts.add(objStr);
      idx = combined.indexOf(anchor, idx + anchor.length);
    }
  }

  const trades = [];
  for (const objStr of foundStarts) {
    let obj;
    try { obj = JSON.parse(objStr); } catch (e) { continue; }
    const politician = obj.politician || {};
    const asset = obj.asset || obj.issuer || {};
    const member = politician.name || [politician.firstName, politician.lastName].filter(Boolean).join(' ');
    const ticker = asset.assetTicker || asset.ticker || (typeof asset === 'string' ? asset : '');
    const assetName = asset.assetName || asset.name || asset.issuerName || '';
    const tradeType = obj.txType || obj.type;
    const date = obj.pubDate || obj.filedDate || obj.txDate || obj.publishedDate;
    if (!member || (!ticker && !assetName) || !date) continue; // data tidak lengkap, lewati

    trades.push({
      chamber: politician.chamber || obj.chamber || 'Kongres AS',
      member,
      trade_type: tradeType || '?',
      ticker: ticker || '',
      asset: assetName || '',
      amount: obj.size || obj.value || '',
      disclosed: date,
      tx_date: obj.txDate || date,
      link: obj.id ? `https://www.capitoltrades.com/trades/${obj.id}` : 'https://www.capitoltrades.com/trades',
    });
    if (trades.length >= 60) break;
  }

  return { trades, sample: combined.slice(0, 3000) };
}

function extractEnclosingObject(text, anchorIndex) {
  // Cari '{' pembuka terdekat sebelum anchor (mundur, hitung kedalaman kurung).
  let depth = 0;
  let start = -1;
  for (let i = anchorIndex; i >= 0; i--) {
    const c = text[i];
    if (c === '}') depth++;
    else if (c === '{') {
      if (depth === 0) { start = i; break; }
      depth--;
    }
  }
  if (start === -1) return null;
  // Dari '{' itu, maju ke depan cari '}' penutup yang sepadan.
  depth = 0;
  for (let i = start; i < text.length && i < start + 20000; i++) {
    const c = text[i];
    if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

/* ============================================================
   /econ-calendar — cache edge, tidak perlu APP_SECRET (data publik).

   KENAPA DIROMBAK (11 Sep 2026): root cause kegagalan yang terus-menerus
   BUKAN cuma "cache kosong sesaat" seperti dugaan sebelumnya. Forex
   Factory (nfs.faireconomy.media) membatasi sangat ketat (hanya update
   1x/jam, dan langsung blokir siapa pun yang dianggap "terlalu sering"
   dengan membalas halaman HTML "Request Denied" alih-alih JSON). Karena
   Cloudflare Workers berbagi rentang IP keluar (egress) dengan RIBUAN
   worker lain milik pengguna Cloudflare di seluruh dunia — dan banyak
   di antaranya kemungkinan juga memanggil endpoint publik FF yang sama —
   worker kita bisa saja SUDAH kena limit itu duluan tanpa kita sendiri
   yang memicunya. Ini beda dari limit browser HP biasa yang IP-nya unik.
   Testing manual berulang (tombol "Coba lagi" ditekan beberapa kali
   dalam <5 menit) juga bisa memperparah/memicu limit ini sendiri.

   SOLUSI: kalau secret FMP_API_KEY diisi (gratis, daftar di
   financialmodelingprep.com, tanpa kartu kredit), worker pakai
   Financial Modeling Prep sebagai sumber UTAMA — bukan proxy/scrape,
   API resmi dengan API key, jauh lebih tahan banting daripada FF.
   Kalau FMP_API_KEY tidak diisi atau gagal, otomatis fallback ke jalur
   lama (fetch langsung FF) — jadi tidak ada regresi buat yang belum
   sempat daftar FMP.

   CATATAN JUJUR: saya belum bisa pastikan 100% endpoint economic-calendar
   FMP ada di tier gratis mereka (dokumentasi mereka tidak eksplisit soal
   ini per endpoint) — coba pakai key gratis dulu; kalau ternyata perlu
   plan berbayar, worker otomatis jatuh ke fallback FF di bawah, jadi
   tidak memperburuk keadaan yang sudah ada.
   ============================================================ */
async function handleEconCalendar(request, env, ctx) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };
  if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const cacheKey = new Request('https://trmnl-econ-cache/calendar-v2', { method: 'GET' });
  const cache = caches.default;

  let cached = await cache.match(cacheKey);
  if (cached) return new Response(cached.body, { headers: { ...corsHeaders, 'Content-Type': 'application/json', 'X-Cache': 'HIT' } });

  // --- Coba FMP dulu kalau key tersedia ---
  if (env.FMP_API_KEY) {
    try {
      const data = await fetchEconFromFMP(env.FMP_API_KEY);
      const resp = new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=1200', 'X-Cache': 'MISS', 'X-Source': 'fmp' },
      });
      ctx.waitUntil(cache.put(cacheKey, resp.clone()));
      return resp;
    } catch (eFmp) {
      console.warn('FMP econ-calendar gagal, fallback ke Forex Factory:', eFmp);
      // lanjut ke fallback FF di bawah, tidak return di sini
    }
  }

  // --- Fallback: Forex Factory langsung (perilaku lama) ---
  let text;
  try {
    const r = await fetch('https://nfs.faireconomy.media/ff_calendar_thisweek.json', {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TRMNL-Worker/1.0)' },
    });
    text = await r.text();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'fetch_failed', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (text.trim().startsWith('<')) {
    // Forex Factory sedang rate-limit bahkan untuk worker kita — jangan cache respons kosong ini.
    return new Response(JSON.stringify({ error: 'upstream_rate_limited' }), {
      status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const resp = new Response(text, {
    headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=900', 'X-Cache': 'MISS', 'X-Source': 'forexfactory' },
  });
  ctx.waitUntil(cache.put(cacheKey, resp.clone()));
  return resp;
}

async function fetchEconFromFMP(apiKey) {
  const today = new Date();
  const from = today.toISOString().slice(0, 10);
  const toDate = new Date(today.getTime() + 7 * 86400000);
  const to = toDate.toISOString().slice(0, 10);
  const url = `https://financialmodelingprep.com/stable/economic-calendar?from=${from}&to=${to}&apikey=${apiKey}`;

  const r = await fetch(url);
  if (!r.ok) throw new Error('FMP respons tidak ok: ' + r.status);
  const d = await r.json();
  if (!Array.isArray(d)) {
    throw new Error('FMP bukan array (kemungkinan API key salah atau endpoint perlu plan berbayar): ' + JSON.stringify(d).slice(0, 300));
  }
  // Normalisasi ke bentuk yang sama dipakai kode lama (title/date/country/impact/forecast/previous)
  // supaya index.html TIDAK perlu diubah sama sekali.
  return d.map((e) => ({
    title: e.event || '(tanpa judul)',
    date: e.date,
    country: e.country || '',
    impact: (e.impact || '').toLowerCase(),
    forecast: e.estimate != null ? String(e.estimate) : '',
    previous: e.previous != null ? String(e.previous) : '',
  }));
}

/* ============================================================
   /ask — proxy ke Gemini API (fitur AI, butuh APP_SECRET)
   ============================================================ */
async function handleAsk(request, env) {
  const corsHeaders = {
    // Untuk keamanan lebih baik, ganti '*' dengan domain GitHub Pages kamu
    // setelah deploy, misal: 'https://username.github.io'
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-App-Secret',
  };

  if (request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders });
  }

  // Proteksi dasar — bukan keamanan sempurna (secret tetap ada di client),
  // tapi cukup mencegah bot/scraper acak menemukan & memakai endpoint ini.
  // Proteksi nyata: batasi juga lewat Cloudflare dashboard (rate limiting rule).
  const appSecret = request.headers.get('X-App-Secret');
  if (!env.APP_SECRET || appSecret !== env.APP_SECRET) {
    return new Response(JSON.stringify({ error: 'unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response(JSON.stringify({ error: 'bad_json' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const query = (body.query || '').toString().slice(0, 500);
  if (!query.trim()) {
    return new Response(JSON.stringify({ error: 'empty_query' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
  const prompt = `Jawab pertanyaan berikut dalam Bahasa Indonesia, singkat (maksimal 4-5 kalimat), jelas, dan berbasis informasi paling terkini yang kamu temukan. Jangan mengarang jika tidak yakin.\n\nPertanyaan: ${query}`;

  let geminiRes;
  try {
    geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': env.GEMINI_API_KEY,
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          tools: [{ google_search: {} }],
        }),
      }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: 'network_error', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (!geminiRes.ok) {
    const errText = await geminiRes.text();
    return new Response(JSON.stringify({ error: 'gemini_error', detail: errText.slice(0, 400) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const data = await geminiRes.json();
  const candidate = data.candidates && data.candidates[0];
  const text =
    (candidate && candidate.content && candidate.content.parts
      ? candidate.content.parts.map((p) => p.text || '').join('')
      : '') || '(Tidak ada jawaban dari model)';

  // Field grounding metadata bisa berbeda nama antar versi API — coba beberapa kemungkinan.
  const gm = candidate && candidate.groundingMetadata;
  const chunks = (gm && (gm.groundingChunks || gm.groundingAttributions)) || [];
  const sources = chunks
    .map((c) => {
      const web = c.web || c.source || {};
      return web.uri || web.url ? { title: web.title || web.uri || web.url, url: web.uri || web.url } : null;
    })
    .filter(Boolean);

  return new Response(JSON.stringify({ text, sources }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

