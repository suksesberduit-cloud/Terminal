/**
 * TRMNL Worker — proxy aman ke Gemini API (AI) + cache kalender ekonomi
 *
 * Kenapa perlu ini: 
 * 1) API key Gemini TIDAK BOLEH ditaruh di kode client-side (index.html) yang
 *    di-hosting publik/APK, karena siapa saja bisa ambil key itu dan pakai
 *    jatah kuota gratis kamu. Worker ini jalan di server Cloudflare, key
 *    disimpan sebagai secret di sana — tidak pernah terkirim ke browser user.
 * 2) Kalender ekonomi (Forex Factory) membatasi 2 request/5 menit dari SATU
 *    sumber. Kalau tiap HP yang buka app ini fetch langsung, gampang kena
 *    limit itu. Worker ini fetch SEKALI per 15 menit lalu simpan di cache
 *    edge Cloudflare — semua user ambil dari cache itu, jadi tidak pernah
 *    lagi membebani (atau kena limit dari) Forex Factory secara langsung.
 *
 * SETUP (lihat SETUP.md untuk panduan lengkap lewat browser HP):
 * 1. Deploy file ini sebagai Cloudflare Worker
 * 2. Set secret: GEMINI_API_KEY (dari Google AI Studio)
 * 3. Set secret: APP_SECRET (bebas, string acak buatanmu sendiri)
 * 4. (Opsional) Set variable: GEMINI_MODEL (default: gemini-flash-latest —
 *    alias resmi Google yang otomatis mengikuti model flash terbaru yang
 *    direkomendasikan, jadi tidak perlu diganti manual tiap ada deprecation)
 * 5. (Opsional, disarankan) Set secret: FMP_API_KEY — key gratis dari
 *    financialmodelingprep.com, dipakai sebagai sumber UTAMA kalender
 *    ekonomi yang jauh lebih tahan banting daripada Forex Factory (lihat
 *    catatan di handleEconCalendar). Kalau tidak diisi, worker otomatis
 *    pakai jalur lama (Forex Factory langsung).
 * 6. Salin URL worker (https://xxx.workers.dev) ke index.html
 *    (dipakai otomatis untuk fitur AI, kalender ekonomi, dan congress trades)
 *
 * CATATAN PENTING SOAL FITUR AI (per 11 Sep 2026, riwayat lengkap):
 * - gemini-2.0-flash: DIMATIKAN TOTAL Google per 1 Juni 2026.
 * - gemini-2.5-flash: DIKUNCI Google khusus untuk API key yang sudah lama
 *   dipakai model itu — API key baru (termasuk kemungkinan besar punya
 *   kamu) langsung dapat 404 "no longer available to new users", TERLEPAS
 *   dari tanggal shutdown resmi (16 Okt 2026) yang jadi tidak relevan lagi.
 * - gemini-3.x: bisa dipakai API key baru, TAPI fitur "cari Google"
 *   (grounding) benar-benar dikunci di tier gratis (perlu billing account).
 * - KEPUTUSAN FINAL: tool google_search DIHAPUS sepenuhnya dari sini.
 *   Sebagai gantinya, client (index.html) fetch berita dulu via Google
 *   News RSS (infrastruktur gratis yang sudah dipakai di tempat lain di
 *   app ini), kirim judul+cuplikannya ke endpoint /ask sebagai "context",
 *   dan Gemini di sini HANYA merangkum context itu — bukan grounding
 *   sendiri. Jadi tidak butuh billing, tidak kena restriksi API key baru,
 *   dan model dipakai (gemini-flash-latest) adalah ALIAS yang otomatis
 *   diarahkan ulang oleh Google ke versi terbaru — tidak perlu lagi ganti
 *   nama model manual tiap kali ada deprecation baru.
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === '/econ-calendar') {
      return handleEconCalendar(request, env, ctx);
    }
    if (url.pathname === '/congress-trades') {
      return handleCongressTrades(request, ctx);
    }
    return handleAsk(request, env);
  },
};

/* ============================================================
   /congress-trades — cache edge, tidak perlu APP_SECRET.

   RIWAYAT (diperbarui 11 Sep 2026): riset sesi sebelumnya sempat
   menyimpulkan congressinvests.com (Railway) sudah mati total — TERNYATA
   KELIRU. User membuktikan lewat screenshot langsung bahwa endpoint itu
   masih hidup dan mengembalikan data asli, segar (tanggal H-3), lengkap
   dengan link PDF resmi disclosures-clerk.house.gov. Jadi source ini
   TETAP dijadikan sumber UTAMA (retry cold-start seperti sebelumnya).

   capitoltrades.com (teknik flight-JSON Next.js) dijadikan fallback KEDUA
   kalau suatu saat Railway itu benar-benar mati — bukan pengganti, karena
   parsernya masih eksperimental/belum terverifikasi live (lihat komentar
   di parseCapitolTradesFlightJson di bawah).
   ============================================================ */
async function handleCongressTrades(request, ctx) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };
  if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const url = new URL(request.url);
  const debug = url.searchParams.get('debug') === '1';

  const cacheKey = new Request('https://trmnl-congress-cache/recent-v2', { method: 'GET' });
  const cache = caches.default;

  if (!debug) {
    let cached = await cache.match(cacheKey);
    if (cached) return new Response(cached.body, { headers: { ...corsHeaders, 'Content-Type': 'application/json', 'X-Cache': 'HIT' } });
  }

  // --- Sumber utama: congressinvests.com (Railway, terbukti hidup) ---
  const railwayUrl = 'https://congressinfor-production.up.railway.app/trades/recent?limit=30&days=45';
  async function tryRailway() {
    const r = await fetch(railwayUrl, { cf: { cacheTtl: 0 } });
    if (!r.ok) throw new Error('railway status ' + r.status);
    const d = await r.json();
    if (!Array.isArray(d.trades) || d.trades.length === 0) throw new Error('railway: data kosong/format tidak sesuai');
    return d; // sudah persis dalam bentuk {trades:[...]} yang dibutuhkan client
  }

  let data = null;
  try {
    data = await tryRailway();
  } catch (e1) {
    console.warn('Railway percobaan 1 gagal, tunggu cold-start lalu coba lagi:', e1);
    await new Promise((res) => setTimeout(res, 5000));
    try {
      data = await tryRailway();
    } catch (e2) {
      console.warn('Railway percobaan 2 juga gagal, fallback ke capitoltrades.com:', e2);
    }
  }

  // --- Fallback: capitoltrades.com (eksperimental, lihat komentar di bawah) ---
  let fallbackDebugInfo = null;
  if (!data) {
    try {
      const html = await fetchCapitolTradesHtml();
      const parsed = parseCapitolTradesFlightJson(html);
      fallbackDebugInfo = { found: parsed.trades.length, sample: parsed.sample };
      if (parsed.trades.length > 0) data = { trades: parsed.trades };
    } catch (e3) {
      fallbackDebugInfo = { error: String(e3) };
      console.warn('Fallback capitoltrades.com juga gagal:', e3);
    }
  }

  if (debug) {
    return new Response(JSON.stringify({
      railway_ok: !!(data && !fallbackDebugInfo),
      used_fallback: !!fallbackDebugInfo,
      fallback_debug: fallbackDebugInfo,
      trades_sample: data ? data.trades.slice(0, 5) : [],
    }, null, 2), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  if (!data) {
    return new Response(JSON.stringify({ error: 'all_sources_failed' }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const resp = new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=1800', 'X-Cache': 'MISS' },
  });
  ctx.waitUntil(cache.put(cacheKey, resp.clone()));
  return resp;
}

async function fetchCapitolTradesHtml() {
  const upstreamUrl = 'https://www.capitoltrades.com/trades?pageSize=100&txDate=90d';
  const r = await fetch(upstreamUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Mobile Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml',
    },
  });
  if (!r.ok) throw new Error('capitoltrades status ' + r.status);
  return r.text();
}

/*
   ⚠️ CATATAN JUJUR soal parseCapitolTradesFlightJson di bawah: ditulis
   berdasarkan riset (teknik "flight-JSON" Next.js dipakai proyek
   open-source capitol-trades-mcp untuk baca situs yang sama), BUKAN hasil
   coba-coba langsung ke capitoltrades.com (lingkungan waktu itu tidak
   bisa akses jaringan luar). Nama field JSON adalah perkiraan terbaik.
   Fungsi ini HANYA jadi fallback kedua (Railway tetap utama), jadi
   risikonya rendah — kalaupun salah, /congress-trades tetap jalan lewat
   Railway seperti biasa. Cara cek/perbaiki kalau perlu: buka
   https://<worker-url>/congress-trades?debug=1 dan lihat "fallback_debug"
   (hanya terisi kalau Railway kebetulan gagal saat itu).
*/
/**
 * Cari semua <script>self.__next_f.push([1,"..."])</script> di HTML,
 * gabungkan isinya (setelah unescape string JS), lalu cari objek JSON
 * yang "berbentuk" seperti data trade (dikenali dari beberapa nama field
 * kandidat) dengan menghitung kurung kurawal secara manual (bukan regex
 * bersarang, karena regex tidak bisa menghitung nested braces dengan andal).
 */
function parseCapitolTradesFlightJson(html) {
  const chunkRe = /self\.__next_f\.push\(\[\s*1\s*,\s*"((?:[^"\\]|\\.)*)"\s*\]\)/g;
  let combined = '';
  let m;
  while ((m = chunkRe.exec(html))) {
    try {
      // payload adalah string JS ter-escape (\n, \", \\u... dst) — unescape
      // dengan trik JSON.parse pada string yang dibungkus tanda kutip.
      combined += JSON.parse('"' + m[1] + '"');
    } catch (e) { /* lewati chunk yang gagal di-unescape, lanjut ke chunk lain */ }
  }

  if (!combined) {
    throw new Error('tidak ditemukan chunk self.__next_f.push sama sekali — kemungkinan struktur halaman sudah berubah total (bukan Next.js App Router lagi, atau butuh JS untuk render)');
  }

  // Kandidat nama field unik yang kemungkinan menandai satu record trade.
  // "reportingGap" dipakai sebagai anchor utama karena nama field ini
  // cukup spesifik/jarang muncul di konteks lain pada halaman yang sama.
  const anchors = ['"reportingGap"', '"politician":{', '"txType"'];
  const foundStarts = new Set();
  for (const anchor of anchors) {
    let idx = combined.indexOf(anchor);
    while (idx !== -1) {
      const objStr = extractEnclosingObject(combined, idx);
      if (objStr) foundStarts.add(objStr);
      idx = combined.indexOf(anchor, idx + anchor.length);
    }
  }

  const trades = [];
  for (const objStr of foundStarts) {
    let obj;
    try { obj = JSON.parse(objStr); } catch (e) { continue; }
    const politician = obj.politician || {};
    const asset = obj.asset || obj.issuer || {};
    const member = politician.name || [politician.firstName, politician.lastName].filter(Boolean).join(' ');
    const ticker = asset.assetTicker || asset.ticker || (typeof asset === 'string' ? asset : '');
    const assetName = asset.assetName || asset.name || asset.issuerName || '';
    const tradeType = obj.txType || obj.type;
    const date = obj.pubDate || obj.filedDate || obj.txDate || obj.publishedDate;
    if (!member || (!ticker && !assetName) || !date) continue; // data tidak lengkap, lewati

    trades.push({
      chamber: politician.chamber || obj.chamber || 'Kongres AS',
      member,
      trade_type: tradeType || '?',
      ticker: ticker || '',
      asset: assetName || '',
      amount: obj.size || obj.value || '',
      disclosed: date,
      tx_date: obj.txDate || date,
      link: obj.id ? `https://www.capitoltrades.com/trades/${obj.id}` : 'https://www.capitoltrades.com/trades',
    });
    if (trades.length >= 60) break;
  }

  return { trades, sample: combined.slice(0, 3000) };
}

function extractEnclosingObject(text, anchorIndex) {
  // Cari '{' pembuka terdekat sebelum anchor (mundur, hitung kedalaman kurung).
  let depth = 0;
  let start = -1;
  for (let i = anchorIndex; i >= 0; i--) {
    const c = text[i];
    if (c === '}') depth++;
    else if (c === '{') {
      if (depth === 0) { start = i; break; }
      depth--;
    }
  }
  if (start === -1) return null;
  // Dari '{' itu, maju ke depan cari '}' penutup yang sepadan.
  depth = 0;
  for (let i = start; i < text.length && i < start + 20000; i++) {
    const c = text[i];
    if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

/* ============================================================
   /econ-calendar — cache edge, tidak perlu APP_SECRET (data publik).

   KENAPA DIROMBAK (11 Sep 2026): root cause kegagalan yang terus-menerus
   BUKAN cuma "cache kosong sesaat" seperti dugaan sebelumnya. Forex
   Factory (nfs.faireconomy.media) membatasi sangat ketat (hanya update
   1x/jam, dan langsung blokir siapa pun yang dianggap "terlalu sering"
   dengan membalas halaman HTML "Request Denied" alih-alih JSON). Karena
   Cloudflare Workers berbagi rentang IP keluar (egress) dengan RIBUAN
   worker lain milik pengguna Cloudflare di seluruh dunia — dan banyak
   di antaranya kemungkinan juga memanggil endpoint publik FF yang sama —
   worker kita bisa saja SUDAH kena limit itu duluan tanpa kita sendiri
   yang memicunya. Ini beda dari limit browser HP biasa yang IP-nya unik.
   Testing manual berulang (tombol "Coba lagi" ditekan beberapa kali
   dalam <5 menit) juga bisa memperparah/memicu limit ini sendiri.

   SOLUSI: kalau secret FMP_API_KEY diisi (gratis, daftar di
   financialmodelingprep.com, tanpa kartu kredit), worker pakai
   Financial Modeling Prep sebagai sumber UTAMA — bukan proxy/scrape,
   API resmi dengan API key, jauh lebih tahan banting daripada FF.
   Kalau FMP_API_KEY tidak diisi atau gagal, otomatis fallback ke jalur
   lama (fetch langsung FF) — jadi tidak ada regresi buat yang belum
   sempat daftar FMP.

   CATATAN JUJUR: saya belum bisa pastikan 100% endpoint economic-calendar
   FMP ada di tier gratis mereka (dokumentasi mereka tidak eksplisit soal
   ini per endpoint) — coba pakai key gratis dulu; kalau ternyata perlu
   plan berbayar, worker otomatis jatuh ke fallback FF di bawah, jadi
   tidak memperburuk keadaan yang sudah ada.
   ============================================================ */
async function handleEconCalendar(request, env, ctx) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };
  if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  const cacheKey = new Request('https://trmnl-econ-cache/calendar-v2', { method: 'GET' });
  const cache = caches.default;

  let cached = await cache.match(cacheKey);
  if (cached) return new Response(cached.body, { headers: { ...corsHeaders, 'Content-Type': 'application/json', 'X-Cache': 'HIT' } });

  // --- Coba FMP dulu kalau key tersedia ---
  if (env.FMP_API_KEY) {
    try {
      const data = await fetchEconFromFMP(env.FMP_API_KEY);
      const resp = new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=1200', 'X-Cache': 'MISS', 'X-Source': 'fmp' },
      });
      ctx.waitUntil(cache.put(cacheKey, resp.clone()));
      return resp;
    } catch (eFmp) {
      console.warn('FMP econ-calendar gagal, fallback ke Forex Factory:', eFmp);
      // lanjut ke fallback FF di bawah, tidak return di sini
    }
  }

  // --- Fallback: Forex Factory langsung (perilaku lama) ---
  let text;
  try {
    const r = await fetch('https://nfs.faireconomy.media/ff_calendar_thisweek.json', {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TRMNL-Worker/1.0)' },
    });
    text = await r.text();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'fetch_failed', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (text.trim().startsWith('<')) {
    // Forex Factory sedang rate-limit bahkan untuk worker kita — jangan cache respons kosong ini.
    return new Response(JSON.stringify({ error: 'upstream_rate_limited' }), {
      status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const resp = new Response(text, {
    headers: { ...corsHeaders, 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=900', 'X-Cache': 'MISS', 'X-Source': 'forexfactory' },
  });
  ctx.waitUntil(cache.put(cacheKey, resp.clone()));
  return resp;
}

async function fetchEconFromFMP(apiKey) {
  const today = new Date();
  const from = today.toISOString().slice(0, 10);
  const toDate = new Date(today.getTime() + 7 * 86400000);
  const to = toDate.toISOString().slice(0, 10);
  const url = `https://financialmodelingprep.com/stable/economic-calendar?from=${from}&to=${to}&apikey=${apiKey}`;

  const r = await fetch(url);
  if (!r.ok) throw new Error('FMP respons tidak ok: ' + r.status);
  const d = await r.json();
  if (!Array.isArray(d)) {
    throw new Error('FMP bukan array (kemungkinan API key salah atau endpoint perlu plan berbayar): ' + JSON.stringify(d).slice(0, 300));
  }
  // Normalisasi ke bentuk yang sama dipakai kode lama (title/date/country/impact/forecast/previous)
  // supaya index.html TIDAK perlu diubah sama sekali.
  return d.map((e) => ({
    title: e.event || '(tanpa judul)',
    date: e.date,
    country: e.country || '',
    impact: (e.impact || '').toLowerCase(),
    forecast: e.estimate != null ? String(e.estimate) : '',
    previous: e.previous != null ? String(e.previous) : '',
  }));
}

/* ============================================================
   /ask — proxy ke Gemini API (fitur AI, butuh APP_SECRET)
   ============================================================ */
/* ============================================================
   /ask — proxy ke Gemini API (fitur AI, butuh APP_SECRET)

   DIROMBAK TOTAL 11 Sep 2026: tool "google_search" (grounding) DIHAPUS.
   Riset mengonfirmasi Google mengunci grounding di tier gratis untuk
   SEMUA model (baik yang punya grounding gratis seperti gemini-2.5-flash
   kini diblokir untuk API key baru — pesan error "no longer available to
   new users" — maupun model baru seperti gemini-3.x yang groundingnya
   memang sengaja dikunci di free tier, perlu billing account).

   Solusi yang dipilih user: RAG manual, gratis 100%, tanpa kartu kredit.
   Client sekarang fetch berita dulu lewat Google News RSS (infrastruktur
   yang sama dipakai kategori berita lain di app, lewat rss2json.com —
   sudah terbukti jalan, tidak butuh key apa pun), lalu kirim judul+snippet
   berita itu ke sini sebagai "context". Gemini di sini HANYA merangkum
   context yang sudah pasti benar itu (bukan mengarang dari grounding
   sendiri) — jadi tidak butuh tool google_search sama sekali, dan tidak
   kena restriksi apa pun di atas.

   Model dipakai: alias "gemini-flash-latest" (bukan versi spesifik) —
   Google otomatis mengarahkan alias ini ke model flash yang sedang
   direkomendasikan saat itu (per catatan changelog resmi mereka, alias
   ini sudah beberapa kali dialihkan ke versi lebih baru). Tujuannya
   supaya TIDAK perlu lagi manual ganti nama model tiap kali ada
   deprecation baru seperti yang berulang kali terjadi sebelumnya.
   ============================================================ */
async function handleAsk(request, env) {
  const corsHeaders = {
    // Untuk keamanan lebih baik, ganti '*' dengan domain GitHub Pages kamu
    // setelah deploy, misal: 'https://username.github.io'
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-App-Secret',
  };

  if (request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders });
  }

  // Proteksi dasar — bukan keamanan sempurna (secret tetap ada di client),
  // tapi cukup mencegah bot/scraper acak menemukan & memakai endpoint ini.
  // Proteksi nyata: batasi juga lewat Cloudflare dashboard (rate limiting rule).
  const appSecret = request.headers.get('X-App-Secret');
  if (!env.APP_SECRET || appSecret !== env.APP_SECRET) {
    return new Response(JSON.stringify({ error: 'unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response(JSON.stringify({ error: 'bad_json' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const query = (body.query || '').toString().slice(0, 500);
  if (!query.trim()) {
    return new Response(JSON.stringify({ error: 'empty_query' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // context = [{title, snippet, link}] dari hasil RSS yang sudah difetch client.
  const context = Array.isArray(body.context) ? body.context.slice(0, 8) : [];

  let contextBlock;
  if (context.length > 0) {
    contextBlock = context
      .map((c, i) => `[${i + 1}] ${(c.title || '').toString().slice(0, 200)}${c.snippet ? ' — ' + c.snippet.toString().slice(0, 300) : ''}`)
      .join('\n');
  } else {
    contextBlock = '(tidak ada artikel berita yang ditemukan untuk kueri ini)';
  }

  const model = env.GEMINI_MODEL || 'gemini-flash-latest';
  const prompt = `Kamu adalah asisten di terminal finansial. Jawab pertanyaan di bawah dalam Bahasa Indonesia, singkat (maksimal 4-5 kalimat), berdasarkan HANYA pada daftar judul+cuplikan berita di bawah ini — jangan mengarang fakta di luar itu. Kalau daftar berita di bawah kosong atau tidak relevan dengan pertanyaan, jawab dari pengetahuan umummu secara singkat DAN sebutkan eksplisit bahwa jawaban ini bukan berdasarkan berita terkini. Kalau memakai info dari daftar, sebutkan nomor sumbernya dalam kurung siku seperti [1] di akhir kalimat terkait.\n\nDaftar berita:\n${contextBlock}\n\nPertanyaan: ${query}`;

  let geminiRes;
  try {
    geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': env.GEMINI_API_KEY,
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
        }),
      }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: 'network_error', detail: String(e) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  if (!geminiRes.ok) {
    const errText = await geminiRes.text();
    return new Response(JSON.stringify({ error: 'gemini_error', detail: errText.slice(0, 400) }), {
      status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const data = await geminiRes.json();
  const candidate = data.candidates && data.candidates[0];
  const text =
    (candidate && candidate.content && candidate.content.parts
      ? candidate.content.parts.map((p) => p.text || '').join('')
      : '') || '(Tidak ada jawaban dari model)';

  // Sumber TIDAK lagi dari grounding metadata Gemini (sudah dihapus) —
  // langsung echo balik daftar berita yang tadi dikirim client, supaya
  // link yang ditampilkan selalu link asli yang benar-benar ada, bukan
  // hasil karangan model.
  const sources = context
    .map((c) => (c.link ? { title: c.title || c.link, url: c.link } : null))
    .filter(Boolean);

  return new Response(JSON.stringify({ text, sources }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

